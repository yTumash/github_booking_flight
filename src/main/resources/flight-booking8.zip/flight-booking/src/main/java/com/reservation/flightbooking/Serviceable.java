package com.reservation.flightbooking;

public interface Serviceable {

    void allowBaggage();

    void allowCarryOn();

    void serveMeals();
}
