package com.reservation.flightbooking;

public interface BookingService {

    void bookSmth(Bookable bookable);
}
