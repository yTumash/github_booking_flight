package com.reservation.flightbooking;

public interface Transferable {

    void changeFlight(Airport id1);

    void changeFlight();
}
